import customtkinter as ctk
from pytube import YouTube
from tkinter import filedialog
from tkinter import font as tkfont

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

root = ctk.CTk()
root.geometry("500x200")

font_path = "Brass Mono.ttf"
font = tkfont.Font(family="Brass Mono")

def done():
    for widget in frame.winfo_children(): widget.destroy()
    label = ctk.CTkLabel(master=frame, text="Finished downloading! Check your downloads folder.", font=("Brass Mono", 14), anchor=ctk.CENTER)
    label.pack(padx=8, pady=12)

def process():
    yt = YouTube(textbox.get())
    ask_type(yt)

def ask_type(yt):
    def b1_action():
        yd = yt.streams.get_highest_resolution()
        download(yd, "video")

    def b2_action():
        yd = yt.streams.get_audio_only()
        download(yd, "audio")

    def download(stream, stream_type):
        folder_path = filedialog.askdirectory(title="Select Folder")
        if stream_type == "audio":
            audio_file_name = f"{yt.title}.mp3"
            stream.download(output_path=folder_path, filename=audio_file_name)
        else: stream.download(output_path=folder_path)
        done()

    for widget in frame.winfo_children(): widget.destroy()

    label = ctk.CTkLabel(master=frame, text="Would you like to save it as a video or audio file?", font=("Brass Mono", 14))
    label.pack(padx=8, pady=12)

    button1 = ctk.CTkButton(master=frame, text="Video", command=b1_action, font=("Brass Mono", 18))
    button1.pack(padx=10, pady=10, side="bottom")

    button2 = ctk.CTkButton(master=frame, text="Audio", command=b2_action, font=("Brass Mono", 18))
    button2.pack(padx=10, pady=10, side="bottom")

frame = ctk.CTkFrame(master=root)
frame.pack(pady=20, padx=60, fill="both", expand=True)

label = ctk.CTkLabel(master=frame, text="YTDownloader", font=("Brass Mono", 24))
label.pack(padx=8, pady=12)

textbox = ctk.CTkEntry(master=frame, placeholder_text="Enter a YouTube Video URL", width=500, font=("Brass Mono", 18))
textbox.pack(padx=8, pady=12)

button = ctk.CTkButton(master=frame, text="Download", font=("Brass Mono", 18), command=process)
button.pack(padx=8, pady=12)

root.mainloop()